# Secure Login System

A full-stack demonstration project for the Thiranex "Secure Login System" task.

## Features
- User registration and login
- Password hashing with bcrypt (12 salt rounds)
- SQLite database with parameterized SQL queries
- Server-side sessions stored in SQLite
- HTTP-only, SameSite session cookies; Secure cookies in production
- Input validation and login rate limiting
- CSRF protection for state-changing API requests
- Optional TOTP two-factor authentication (authenticator app + QR code)
- Logout and responsive dashboard
- Helmet security headers and a restrictive Content Security Policy

## Requirements
- Node.js 20 or newer
- npm

## Run locally
1. Extract the project ZIP and open the folder in VS Code.
2. Open a terminal in this folder.
3. Install dependencies:
   ```bash
   npm install
   ```
4. Create your environment file:
   - Windows PowerShell: `Copy-Item .env.example .env`
   - macOS/Linux: `cp .env.example .env`
5. Open `.env` and replace `SESSION_SECRET` with a long random secret (at least 32 characters).
6. Start the app:
   ```bash
   npm start
   ```
7. Open http://localhost:3000 in your browser.

The `data/` directory and SQLite database are created automatically.

## Enable optional 2FA
1. Register and sign in.
2. Click **Set up 2FA**.
3. Scan the QR code using an authenticator app such as Aegis or Google Authenticator.
4. Enter the current 6-digit code to enable it.
5. On future logins, enter the authenticator code after your password.

## Security notes
- Never commit `.env` or database files.
- Use HTTPS in production and set `NODE_ENV=production`.
- Use a unique, high-entropy `SESSION_SECRET`.
- Back up the database securely.
- This is an educational project starter, not a formally audited authentication service. Before real-world deployment, add account recovery, email verification, monitoring, dependency updates, and a reviewed production deployment configuration.
