const $ = (id) => document.getElementById(id);
let mode = "login";
let csrfToken = "";

async function refreshCsrf() {
  const response = await fetch("/api/csrf");
  const data = await response.json();
  csrfToken = data.csrfToken;
}
function showMessage(message, type = "error") {
  const box = $("message");
  box.textContent = message;
  box.className = `message show ${type}`;
}
function clearMessage() {
  $("message").textContent = "";
  $("message").className = "message";
}
async function api(url, body) {
  const response = await fetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/json", "X-CSRF-Token": csrfToken },
    body: JSON.stringify(body)
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.error || "Request failed.");
  return data;
}
function setMode(nextMode) {
  mode = nextMode;
  clearMessage();
  $("loginTab").classList.toggle("active", mode === "login");
  $("registerTab").classList.toggle("active", mode === "register");
  $("submitButton").textContent = mode === "login" ? "Sign in" : "Create account";
  $("password").autocomplete = mode === "login" ? "current-password" : "new-password";
  $("passwordHint").classList.toggle("hidden", mode === "login");
}
$("loginTab").addEventListener("click", () => setMode("login"));
$("registerTab").addEventListener("click", () => setMode("register"));

$("authForm").addEventListener("submit", async (event) => {
  event.preventDefault();
  clearMessage();
  const email = $("email").value.trim();
  const password = $("password").value;
  try {
    const result = await api(mode === "login" ? "/api/login" : "/api/register", { email, password });
    if (result.requires2FA) {
      $("authForm").classList.add("hidden");
      $("twoFactorForm").classList.remove("hidden");
      showMessage("Enter the code from your authenticator app.", "success");
      return;
    }
    await refreshCsrf();
    await loadDashboard();
  } catch (error) {
    showMessage(error.message);
  }
});

$("twoFactorForm").addEventListener("submit", async (event) => {
  event.preventDefault();
  try {
    await api("/api/2fa/verify-login", { token: $("loginToken").value.trim() });
    await refreshCsrf();
    await loadDashboard();
  } catch (error) { showMessage(error.message); }
});

async function loadDashboard() {
  const response = await fetch("/api/me");
  if (!response.ok) return;
  const { user } = await response.json();
  $("authCard").classList.add("hidden");
  $("dashboard").classList.remove("hidden");
  $("userEmail").textContent = user.email;
  $("twoFactorStatus").textContent = user.twoFactorEnabled ? "Enabled" : "Not enabled";
  $("setup2fa").classList.toggle("hidden", user.twoFactorEnabled);
}
$("setup2fa").addEventListener("click", async () => {
  try {
    const data = await api("/api/2fa/setup", {});
    $("qrImage").src = data.qrCode;
    $("secretText").textContent = data.secret;
    $("twoFactorSetup").classList.remove("hidden");
  } catch (error) { showMessage(error.message); }
});
$("enable2faForm").addEventListener("submit", async (event) => {
  event.preventDefault();
  try {
    const data = await api("/api/2fa/enable", { token: $("enableToken").value.trim() });
    $("twoFactorSetup").classList.add("hidden");
    showMessage(data.message, "success");
    await loadDashboard();
  } catch (error) { showMessage(error.message); }
});
$("logoutButton").addEventListener("click", async () => {
  try {
    await api("/api/logout", {});
    location.reload();
  } catch (error) { showMessage(error.message); }
});

(async function init() {
  try {
    await refreshCsrf();
    await loadDashboard();
  } catch (error) {
    showMessage("Unable to connect to the server. Please refresh.");
  }
})();
