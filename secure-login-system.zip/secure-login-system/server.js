require("dotenv").config();

const path = require("path");
const fs = require("fs");
const express = require("express");
const session = require("express-session");
const SQLiteStore = require("connect-sqlite3")(session);
const Database = require("better-sqlite3");
const bcrypt = require("bcryptjs");
const helmet = require("helmet");
const { rateLimit } = require("express-rate-limit");
const { authenticator } = require("otplib");
const QRCode = require("qrcode");

const app = express();
const PORT = Number(process.env.PORT || 3000);
const isProduction = process.env.NODE_ENV === "production";
const sessionSecret = process.env.SESSION_SECRET;

if (!sessionSecret || sessionSecret.length < 32) {
  console.error("Set SESSION_SECRET in .env (at least 32 characters).");
  process.exit(1);
}

if (isProduction) app.set("trust proxy", 1);

const dataDir = path.join(__dirname, "data");
fs.mkdirSync(dataDir, { recursive: true });
const db = new Database(path.join(dataDir, "app.sqlite"));
db.pragma("journal_mode = WAL");
db.pragma("foreign_keys = ON");
db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    email TEXT NOT NULL UNIQUE COLLATE NOCASE,
    password_hash TEXT NOT NULL,
    totp_secret TEXT,
    totp_enabled INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
  );
`);

app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      scriptSrc: ["'self'"],
      styleSrc: ["'self'"],
      imgSrc: ["'self'", "data:"],
      connectSrc: ["'self'"],
      objectSrc: ["'none'"],
      upgradeInsecureRequests: isProduction ? [] : null
    }
  }
}));
app.use(express.json({ limit: "10kb" }));
app.use(express.urlencoded({ extended: false, limit: "10kb" }));

app.use(session({
  store: new SQLiteStore({ db: "sessions.sqlite", dir: dataDir, concurrentDB: true }),
  name: "securelogin.sid",
  secret: sessionSecret,
  resave: false,
  saveUninitialized: false,
  cookie: {
    httpOnly: true,
    secure: isProduction,
    sameSite: "lax",
    maxAge: 1000 * 60 * 60 * 2
  }
}));

// Synchronizer-token CSRF protection for all state-changing API requests.
function safeEqual(a, b) {
  const crypto = require("crypto");
  const left = Buffer.from(String(a || ""));
  const right = Buffer.from(String(b || ""));
  return left.length === right.length && crypto.timingSafeEqual(left, right);
}
app.get("/api/csrf", (req, res) => {
  if (!req.session.csrfToken) {
    req.session.csrfToken = require("crypto").randomBytes(32).toString("hex");
  }
  res.json({ csrfToken: req.session.csrfToken });
});
app.use("/api", (req, res, next) => {
  if (["GET", "HEAD", "OPTIONS"].includes(req.method)) return next();
  if (!safeEqual(req.session.csrfToken, req.get("x-csrf-token"))) {
    return res.status(403).json({ error: "Request verification failed. Refresh and try again." });
  }
  next();
});

const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  limit: 10,
  standardHeaders: "draft-7",
  legacyHeaders: false,
  message: { error: "Too many attempts. Please try again after 15 minutes." }
});

function normalizeEmail(value) {
  return String(value || "").trim().toLowerCase();
}
function validEmail(email) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) && email.length <= 254;
}
function validPassword(password) {
  return typeof password === "string" &&
    password.length >= 10 &&
    password.length <= 72 &&
    /[a-z]/.test(password) &&
    /[A-Z]/.test(password) &&
    /\d/.test(password);
}
function publicUser(user) {
  return {
    id: user.id,
    email: user.email,
    twoFactorEnabled: Boolean(user.totp_enabled)
  };
}
function requireAuth(req, res, next) {
  if (!req.session.userId) return res.status(401).json({ error: "Please log in first." });
  next();
}

app.post("/api/register", authLimiter, async (req, res) => {
  const email = normalizeEmail(req.body.email);
  const password = req.body.password;

  if (!validEmail(email)) return res.status(400).json({ error: "Enter a valid email address." });
  if (!validPassword(password)) {
    return res.status(400).json({ error: "Password must be 10–72 characters and include uppercase, lowercase and a number." });
  }

  try {
    const passwordHash = await bcrypt.hash(password, 12);
    const result = db.prepare(
      "INSERT INTO users (email, password_hash) VALUES (?, ?)"
    ).run(email, passwordHash);

    req.session.regenerate((err) => {
      if (err) return res.status(500).json({ error: "Could not create a secure session." });
      req.session.userId = Number(result.lastInsertRowid);
      req.session.csrfToken = require("crypto").randomBytes(32).toString("hex");
      res.status(201).json({ message: "Account created successfully." });
    });
  } catch (error) {
    if (String(error.code).includes("SQLITE_CONSTRAINT")) {
      return res.status(409).json({ error: "An account with this email already exists." });
    }
    console.error(error);
    res.status(500).json({ error: "Something went wrong. Please try again." });
  }
});

app.post("/api/login", authLimiter, async (req, res) => {
  const email = normalizeEmail(req.body.email);
  const password = req.body.password;
  if (!validEmail(email) || typeof password !== "string" || password.length > 72) {
    return res.status(400).json({ error: "Enter a valid email and password." });
  }

  const user = db.prepare("SELECT * FROM users WHERE email = ?").get(email);
  // Same outward response for unknown email and incorrect password.
  const hashToCheck = user ? user.password_hash : "$2a$12$C6UzMDM.H6dfI/f/IKcEe.3O5P0Y5VQwL7s8M5Kq6p2k0f4mY5m";
  const matches = await bcrypt.compare(password, hashToCheck).catch(() => false);
  if (!user || !matches) return res.status(401).json({ error: "Invalid email or password." });

  req.session.regenerate((err) => {
    if (err) return res.status(500).json({ error: "Could not create a secure session." });
    req.session.csrfToken = require("crypto").randomBytes(32).toString("hex");
    if (user.totp_enabled) {
      req.session.pending2faUserId = user.id;
      return res.json({ requires2FA: true, message: "Enter your authenticator code." });
    }
    req.session.userId = user.id;
    res.json({ message: "Logged in successfully." });
  });
});

app.post("/api/2fa/verify-login", authLimiter, (req, res) => {
  const userId = req.session.pending2faUserId;
  const token = String(req.body.token || "").replace(/\s/g, "");
  if (!userId || !/^\d{6}$/.test(token)) {
    return res.status(400).json({ error: "Enter the 6-digit authenticator code." });
  }
  const user = db.prepare("SELECT * FROM users WHERE id = ?").get(userId);
  if (!user || !user.totp_enabled || !authenticator.check(token, user.totp_secret)) {
    return res.status(401).json({ error: "Invalid authenticator code." });
  }
  delete req.session.pending2faUserId;
  req.session.userId = user.id;
  res.json({ message: "Two-factor verification successful." });
});

app.get("/api/me", requireAuth, (req, res) => {
  const user = db.prepare("SELECT id, email, totp_enabled FROM users WHERE id = ?").get(req.session.userId);
  if (!user) return req.session.destroy(() => res.status(401).json({ error: "Session expired." }));
  res.json({ user: publicUser(user) });
});

app.post("/api/logout", requireAuth, (req, res) => {
  req.session.destroy((err) => {
    if (err) return res.status(500).json({ error: "Could not log out." });
    res.clearCookie("securelogin.sid", { httpOnly: true, sameSite: "lax", secure: isProduction });
    res.json({ message: "Logged out successfully." });
  });
});

app.post("/api/2fa/setup", requireAuth, async (req, res) => {
  const user = db.prepare("SELECT id, email, totp_enabled FROM users WHERE id = ?").get(req.session.userId);
  if (user.totp_enabled) return res.status(400).json({ error: "Two-factor authentication is already enabled." });

  const secret = authenticator.generateSecret();
  const otpauth = authenticator.keyuri(user.email, "Secure Login System", secret);
  req.session.pendingTotpSecret = secret;
  const qrCode = await QRCode.toDataURL(otpauth);
  res.json({ qrCode, secret, message: "Scan the QR code, then enter the 6-digit code to enable 2FA." });
});

app.post("/api/2fa/enable", requireAuth, (req, res) => {
  const secret = req.session.pendingTotpSecret;
  const token = String(req.body.token || "").replace(/\s/g, "");
  if (!secret) return res.status(400).json({ error: "Start 2FA setup first." });
  if (!/^\d{6}$/.test(token) || !authenticator.check(token, secret)) {
    return res.status(400).json({ error: "Invalid code. Check your authenticator app and try again." });
  }
  db.prepare("UPDATE users SET totp_secret = ?, totp_enabled = 1 WHERE id = ?")
    .run(secret, req.session.userId);
  delete req.session.pendingTotpSecret;
  res.json({ message: "Two-factor authentication enabled." });
});

app.use(express.static(path.join(__dirname, "public")));
app.use((req, res) => res.status(404).send("Page not found."));

app.listen(PORT, () => {
  console.log(`Secure Login System running at http://localhost:${PORT}`);
});
